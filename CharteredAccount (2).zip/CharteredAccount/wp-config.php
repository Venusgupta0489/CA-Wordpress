<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'CharteredAcnt' );

/** Database username */
define( 'DB_USER', 'root' );

/** Database password */
define( 'DB_PASSWORD', '' );

/** Database hostname */
define( 'DB_HOST', 'localhost' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         '_vhP7dWj^v77X;.jsyJ6i+,OS7alSt^0f9@ZlTIW8E9~*,oOhjZ7BtM#_s7/D=4{' );
define( 'SECURE_AUTH_KEY',  'TJ|5cDl9JBHw?Dr3R.>}!`cJ)hk?Ekuh}9!-C,42Uk_XBC,s]?ht!qQF1>{Wu`,A' );
define( 'LOGGED_IN_KEY',    'oL(E36L##9cL~AI.geo!sxm?,R]9_Z&[;]n<1X;yDhxnxXb*>q)/cKZvax&]a/=0' );
define( 'NONCE_KEY',        '/T>z6o,d}eJRtmdyK$ae&`VDUGvhT{2piOn$d:5sejVc)jO?) )~b5jY-+2k^=we' );
define( 'AUTH_SALT',        '-G|)kUCKrie/{9-_O) k@qN:g:-$bXB~;Fz/|]v/q( JU)lEDM^@jst.i;4J_:c~' );
define( 'SECURE_AUTH_SALT', 'g%{1q=WPe-hz#>+R]U|_T|jV`BcC04}^9`GoS.P4%ZefJ6O+d4A]$V|6ONVVFX~k' );
define( 'LOGGED_IN_SALT',   '33J7sk8K2yy=9L=!Pa;t$SCU,=m75+:<x6xpHejSbP?eH]^%@Ww.:tGE_7.C+)QH' );
define( 'NONCE_SALT',       'v3Tv}2R:Lf_FitpcZ4@(v6J5QN=h!Q[dr#y>PH#5C-a}0ZF]=6R6f4PIWM]&b*k+' );

/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* Add any custom values between this line and the "stop editing" line. */



/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
